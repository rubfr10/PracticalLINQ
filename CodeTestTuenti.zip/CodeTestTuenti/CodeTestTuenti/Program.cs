﻿using CodeTestTuenti.Methods;
using CodeTestTuenti.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Data;

namespace CodeTestTuenti
{
    class Program
    {
        
        static void Main(string[] args)
        {
            bool winTeamA = false;
            bool winTeamB = false;
            string mvpBasket = string.Empty;
            string mvpHandball = string.Empty;


            //Parse Json
            string json = JsonMethods.readJson("B");
            List<MatchBasketball> matchBasketball = JsonConvert.DeserializeObject<List<MatchBasketball>>(json);

            json = JsonMethods.readJson("H");
            List<MatchHandball> matchHandball = JsonConvert.DeserializeObject<List<MatchHandball>>(json);

            //Create tables from JSon Parse
            DataTable dtBasket = DataMethods.createDataTableBasketball(matchBasketball);

            DataTable dtHandball = DataMethods.createDataTableHandball(matchHandball);


            //Calculate point of every team in basket
            int pointsBasketA = DataMethods.sumPointTeamBasket(dtBasket, "A");
            int pointsBasketB = DataMethods.sumPointTeamBasket(dtBasket, "B");

            //Calculate team winner
            if (pointsBasketA > pointsBasketB)
            {
                winTeamA = true;
            }else
            {
                winTeamB = true;
            }

            //Calculate mvp from teamWiner
            if (winTeamA)
            {
                mvpBasket = DataMethods.getMvp(dtBasket, "A");
            }
            if (winTeamB)
            {
                mvpBasket = DataMethods.getMvp(dtBasket, "B");
            }

            //Calculate point of every team in handball
            int diffGoalsHandballA = DataMethods.sumPointTeamHandball(dtHandball, "A");
            int diffGoalsHandballB = DataMethods.sumPointTeamHandball(dtHandball, "B");

            //Calculate team winner
            if (diffGoalsHandballA < diffGoalsHandballB)
            {
                winTeamA = true;
            }
            else
            {
                winTeamB = true;
            }

            //Calculate mvp from teamWiner
            if (winTeamA)
            {
                mvpHandball = DataMethods.getMvp(dtHandball, "A");
            }
            if (winTeamB)
            {
                mvpHandball = DataMethods.getMvp(dtHandball, "B");
            }

        }

        
    }
}
