﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeTestTuenti.Methods
{
    public static class JsonMethods
    {
        public static string readJson(string typeSport)
        {
            string json = string.Empty;
            string fileName = string.Empty;

            if (typeSport.Equals("B"))
            {
                fileName = "matchBasketball.json";
            }
            else
            {
                fileName = "matchHandball.json";
            }

            using (StreamReader sr = new StreamReader("..//..//Json//" + fileName))
            {
                json = sr.ReadToEnd();
            }

            return json;
        }
    }
}
