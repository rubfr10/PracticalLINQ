﻿using CodeTestTuenti.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeTestTuenti.Methods
{
    public static class DataMethods
    {
        public static DataTable createDataTableBasketball(List<MatchBasketball> listMatchBasket)
        {
            DataTable dtBasket = new DataTable();

            dtBasket.Columns.Add("Nick");
            dtBasket.Columns.Add("Team");
            dtBasket.Columns.Add("Position");
            dtBasket.Columns.Add("scoredPoint");
            dtBasket.Columns.Add("Rebounds");
            dtBasket.Columns.Add("Assists");
            dtBasket.Columns.Add("RatingPoints");

            foreach (MatchBasketball match in listMatchBasket)
            {
                DataRow dr = dtBasket.NewRow();

                dr["Nick"] = match.player.nickname.ToString();
                dr["Team"] = match.team.ToString();
                dr["Position"] = match.position.ToString();
                dr["scoredPoint"] = match.scoredPoint;
                dr["Rebounds"] = match.rebounds;
                dr["Assists"] = match.assists;

                switch (match.position.ToString())
                {
                    case "G":
                        dr["RatingPoints"] = match.scoredPoint * 2 + match.rebounds * 3 + match.assists;
                        break;
                    case "F":
                        dr["RatingPoints"] = match.scoredPoint * 2 + match.rebounds * 2 + match.assists * 2;
                        break;
                    case "C":
                        dr["RatingPoints"] = match.scoredPoint * 2 + match.rebounds * 1 + match.assists * 3;
                        break;
                }
                

                dtBasket.Rows.Add(dr);
            }

            return dtBasket;
        }

        public static DataTable createDataTableHandball(List<MatchHandball> listMatchHandball)
        {
            DataTable dtHandball = new DataTable();

            dtHandball.Columns.Add("Nick");
            dtHandball.Columns.Add("Team");
            dtHandball.Columns.Add("Position");
            dtHandball.Columns.Add("goalMade");
            dtHandball.Columns.Add("goalReceived");
            dtHandball.Columns.Add("initialPoints");
            dtHandball.Columns.Add("RatingPoints");

            foreach (MatchHandball match in listMatchHandball)
            {
                DataRow dr = dtHandball.NewRow();

                dr["Nick"] = match.player.nickname.ToString();
                dr["Team"] = match.team.ToString();
                dr["Position"] = match.position.ToString();
                dr["goalMade"] = match.goalMade;
                dr["goalReceived"] = match.goalReceived;

                if (match.position.ToString().Equals("G"))
                {
                    dr["initialPoints"] = 50;
                }else if (match.position.ToString().Equals("F"))
                {
                    dr["initialPoints"] = 20;
                }

                switch (match.position.ToString())
                {
                    case "G":
                        dr["RatingPoints"] = match.initialPoints + match.goalMade * 5 + match.goalReceived * -2;
                        break;
                    case "F":
                        dr["RatingPoints"] = match.initialPoints + match.goalMade + match.goalReceived * -1;
                        break;
                }


                dtHandball.Rows.Add(dr);
            }

            return dtHandball;
        }

        public static int sumPointTeamBasket(DataTable dtBasket, string team)
        {
            int points = int.MinValue;
            string aa = string.Empty;

            points = dtBasket.AsEnumerable().Where(a => a.Field<string>("Team").ToString().Equals(team)).Select(a => Convert.ToInt32(a.Field<string>("scoredPoint"))).Sum();

            return points;
        }

        public static int sumPointTeamHandball(DataTable dtHandball, string team)
        {
            int goalMade = int.MinValue;
            int goalReceived = int.MinValue;
            int difGoals = int.MinValue;

            goalMade =  dtHandball.AsEnumerable().Where(a => a.Field<string>("team").ToString().Equals(team)).Select(a => Convert.ToInt32(a.Field<string>("goalMade"))).Sum();
            goalReceived = dtHandball.AsEnumerable().Where(a => a.Field<string>("team").ToString().Equals(team)).Select(a => Convert.ToInt32(a.Field<string>("goalReceived"))).Sum();

            difGoals = goalMade - goalReceived;

            return difGoals;
        }

        public static string getMvp(DataTable dt, string team)
        {
            string mvp = string.Empty;

            DataTable players = dt.AsEnumerable().Where(a => a.Field<string>("team").ToString().Equals(team)).OrderByDescending(a => Convert.ToInt32(a.Field<string>("RatingPoints"))).CopyToDataTable();

            mvp = players.AsEnumerable().Select(a => a.Field<string>("Nick")).FirstOrDefault();

            return mvp;
        }
    }
}
