﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeTestTuenti.Entities
{
    public class MatchBasketball
    {
        public Player player { get; set; }
        public string team { get; set; }
        public string position { get; set; }
        public int scoredPoint { get; set; }
        public int rebounds { get; set; }
        public int assists { get; set; }
    }
}
