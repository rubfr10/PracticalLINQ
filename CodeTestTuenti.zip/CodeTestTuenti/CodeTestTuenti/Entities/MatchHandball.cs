﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeTestTuenti.Entities
{
    public class MatchHandball
    {
        public Player player { get; set; }
        public string team { get; set; }
        public string position { get; set; }
        public int initialPoints { get; set; }
        public int goalMade { get; set; }
        public int goalReceived { get; set; }
    }
}
